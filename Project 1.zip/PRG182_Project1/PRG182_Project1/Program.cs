﻿using System.Collections;

namespace PRG182_Project1
{
    internal class Program
    {

        enum Menu{
            mCapture = '1', mEmployees = '2', mStatus = '3', mExit = 'e'
        }
        static void Main(string[] args)   
        {
            List<ArrayList> data = new List<ArrayList>();
            


        Menu: //used for the goto. Instead of breaking in the switch, this will allow the menu to be displayed until the user exits the program.
            Console.Clear();
            Console.WriteLine("======================= Welcome to Lawry =======================");
            Console.WriteLine("\n" +
                "Please select an item from the menu:\n" +
                "\n" +
                "1. Capture Details. \n" +
                "2. Display all entries. \n" +
                "3. Show qualification status. \n" +
                "e. Exit\n" +
                "");

            
            char.TryParse(Console.ReadLine(), out char option);

            

            switch ((Menu)option)
            {
                case Menu.mCapture://the capture option on the menu
                CaptureDetails:
                    Console.Clear();
                    Console.WriteLine("======================= Welcome to Lawry =======================");
                    Console.WriteLine("Capture Details: \n" +
                        "");
                    Console.WriteLine();

                    data.Add(CaptureDetails());              


                MoreDetails:
                    Console.WriteLine();
                    Console.WriteLine("=======================================");
                    Console.WriteLine("Do you want to capture more details? \n" +
                        "\n" +
                        "Select one of the following options:  \n" +
                        "Yes - y\n" +
                        "No - n");

                    char.TryParse(Console.ReadLine(), out char cMoreDetails);//checks if the user inputs a character, if not a null value will be returned, and the default case in the switch statement will execute.

                    switch (cMoreDetails)
                    {
                        case 'y':
                            goto CaptureDetails;

                        case 'n':
                            break;

                        default:
                            Console.WriteLine("Invalid Input! \n" +
                                "Press enter to continue...\n");
                            Console.ReadKey(); //waits for user input before the program returns
                            goto MoreDetails;
                    }               
                   

                    Console.WriteLine("Press any key to go back to the main menu...");
                    Console.ReadKey();

                   
                    goto Menu;//returns To the menu once the code has been executed

                case Menu.mEmployees:
                    Console.Clear();
                    Console.WriteLine("======================= Welcome to Lawry =======================");
                    Console.WriteLine("Employees: \n" +
                        "\n" +
                        "Employee name | Employee status | Years in current job | Years at current residence | Monthly salary | Amount of non-mortgage dept | Number of children | Credit status qualification |");


                    foreach (var entry in data)//access every individual arraylist
                    {
                        Console.Write("| ");
                        foreach (var i in entry)//access every individual item in the arraylist
                        {
                            Console.Write($"{i} \t| ");
                        }
                        Console.WriteLine();
                    }                    

                    Console.WriteLine("\n Press any key to go back to the main menu...");
                    Console.ReadKey();
                    goto Menu;//returns To the menu once the code has been executed

                case Menu.mStatus:
                    ArrayList arrQualified = new ArrayList();
                    ArrayList arrNonQualified = new ArrayList();
;

                    Console.Clear();
                    Console.WriteLine("======================= Welcome to Lawry =======================");
                    Console.WriteLine("Show qualification stats: \n" +
                        "");

                    foreach (var entry in data)//access every individual arraylist
                    {                        
                        if ((bool)entry[7] == false)//checks the qualification status
                        {
                            arrNonQualified.Add((string)entry[0]);                            
                        }
                        else
                        {
                            arrQualified.Add((string)entry[0]);
                        }
                    }

                    //display qualified 
                    Console.WriteLine("Qualified entries:");
                    foreach (var entry in arrQualified)//access every individual arraylist
                    {
                        Console.WriteLine(entry);
                    }

                    Console.WriteLine();//makes a visual space between the categories

                    //display non-qualified 
                    Console.WriteLine("Non-qualified entries:");
                    foreach (var entry in arrNonQualified)//access every individual arraylist
                    {
                        Console.WriteLine(entry);
                    }

                    Console.WriteLine("\n Press any key to go back to the main menu...");
                    Console.ReadKey();
                    goto Menu;//returns To the menu once the code has been executed

                case Menu.mExit:
                    Console.Clear();
                    Console.WriteLine("======================= Welcome to Lawry =======================");
                    Console.WriteLine("Exiting the program...");
                    System.Threading.Thread.Sleep(400);//waits before exiting the code, to let the user know the program is exiting
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("Invalid input!");
                    goto Menu;
            }

            Console.ReadKey();
        }       

        public static ArrayList CaptureDetails()
        {
            ArrayList newData = new ArrayList();

            Console.WriteLine("Please enter the Applicant Name: ");
            bool bAppName = false;
            string appName = Console.ReadLine();
            while (bAppName == false)//error catching
            {
                if (string.IsNullOrEmpty(appName))
                {
                    Console.WriteLine("Please enter text.");
                    appName = Console.ReadLine();
                }
                else
                {
                    newData.Add(appName);
                    bAppName = true;
                }
            }            

            Console.WriteLine("Please enter the Employee Status: \n" +
                "Employed - y, Not employed - n");
            bool bStatus = false;            
            while (bStatus == false)//error catching
            {
                if (char.TryParse(Console.ReadLine(), out char status) && (status == 'y' || status == 'n'))//error catching
                {
                    newData.Add(status);
                    bStatus = true;
                }//end if
                else
                {
                    Console.WriteLine("Please enter a valid value. (y/n)");
                }//end else            
            }//end while


            Console.WriteLine("Please enter the Years in current job: ");
            bool bYears = false;
            while (bYears == false)
            {
                if (int.TryParse(Console.ReadLine(), out int years))//error catching
                {
                    newData.Add(years);
                    bYears = true;
                }//end if
                else
                {
                    Console.WriteLine("Please enter a valid integer value.");
                }//end else
            }//end while            

            Console.WriteLine("Please enter the Years at current residence: ");
            bool bYearsResidence = false;
            while (bYearsResidence == false)
            {
                if (int.TryParse(Console.ReadLine(), out int yearsResidence))//error catching
                {
                    newData.Add(yearsResidence);
                    bYearsResidence = true;
                }//end if
                else
                {
                    Console.WriteLine("Please enter a valid integer value.");
                }//end else
            }//end while            

            Console.WriteLine("Please enter the Monthly Salary: ");
            bool bSalary = false;
            while (bSalary == false)
            {
                if (double.TryParse(Console.ReadLine(), out double salary))//error catching
                {
                    newData.Add(salary);
                    bSalary = true;
                }//end if
                else
                {
                    Console.WriteLine("Please enter a valid double value.");
                }//end else
            }//end while

            Console.WriteLine("Please enter the Amount of non-morrgage dept: ");
            bool bDept = false;
            while (bDept == false)
            {
                if (double.TryParse(Console.ReadLine(), out double dept))//error catching
                {
                    newData.Add(dept);
                    bDept = true;
                }//end if
                else
                {
                    Console.WriteLine("Please enter a valid double value.");
                }//end else
            }//end while            

            Console.WriteLine("Please enter the Number of children: ");
            bool bChildren = false;
            while (bChildren == false)
            {
                if (int.TryParse(Console.ReadLine(), out int children))//error catching
                {
                    newData.Add(children);
                    bChildren = true;
                }//end if
                else
                {
                    Console.WriteLine("Please enter a valid integer value.");
                }//end else
            }//end while                               

            //check if the new entry qualifies for credit

            newData.Add(CreditQualification((int)newData[2], (int)newData[3], (double)newData[4], (double)newData[5], (int)newData[6]));//adds the qualificaltion to the last element in the arraylist
           
           
            return newData;
        

        }////end captureDetails
    
        public static bool CreditQualification(int yearsinCurrentJob, int yearsAtCurrentResidence, double monthlySalary, double amtOfDept, int children)
        {

            //the neccessary arrayList items are transfered to the method via arguments.

            bool bQualify = false;

            //bools for testing the conditions:
            bool bYearsInCurrentJob = false;
            bool bYearsInCurrentResidence = false;
            bool bDept = false;
            bool bChildren = false;


            if (yearsinCurrentJob > 1)//test whether they work at the same job for more than a year.
            {
                bYearsInCurrentJob = true;
            }

            if (yearsAtCurrentResidence >= 2)
            {
                bYearsInCurrentResidence = true;
            }            

            if (amtOfDept < (monthlySalary*2))
            {
                bDept = true;
            }

            if (children < 6)
            {
                bChildren = true;
            }           
              
            //return the bool value that determines if the employee qualifies.
            if (bYearsInCurrentJob && bYearsInCurrentResidence && bDept && bChildren)
            {
                bQualify = true;
            }
            return bQualify;
            
        }        
    }
}